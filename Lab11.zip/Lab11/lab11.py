##Michael Nweke #Student ID: 16278575 #Lab 11
#Define a functin to get a name that is in the file
def get_friend(network):
#Start a while loop that will ask for a valid person and will continue to ask until it gets a valid name
    ask=True
    while ask:
        name=input('Enter a valid person ==>')
        if name in network:
            ask=False
        else:
            print(name, 'is not part of this network, enter another name.')
    return name
#Create a function that creates a set
def add_person(network, key, friend):
    if key not in network:
        network[key]=set()
        network[key].add(friend)
    if key in network:
        network[key].add(friend)
#Create a function that opnes the file and called the add_person function in order add the created sets to the dictionary
def open_file():
    names={}
    with open('friends.txt') as file:
        for line in file:
            name1, name2=line.split(' ')
            name1, name2=name1.strip(), name2.strip()
            
            add_person(names, name1, name2)
            add_person(names, name2, name1)
    return names
names=open_file()

#Create the 'social network' docstring menu that will take the user's input
#Start a while loop that will ask the user for their choice until they input a valid choice
ask=True
while ask:
    menu=input('''Social Network

I. Find all friends shared by 2 people
D. Find all friends of X that person Y does not have
S. Find all friends that X and Y have, but do not share with each other
Q. Quit

==>''').upper()

#Create a list of valid choices for menu
    choices=['I','D','S','Q']
#If choice isn't valid, user will be prompted to enter another choice
    if menu not in choices:
        print('Invalid choice, enter a choice from the given menu')
    else:
        if menu=='I':
    #The get_friend function will be called to get valid names to compare with
            name1=get_friend(names)
            name2=get_friend(names)
    #Call the intersection function to create a new set and assign it to a variable to be printed
            result=names[name1].intersection(names[name2])
            print('\n{} and {} share these people {}'.format(name1, name2, result))
        if menu=='D':
   #The get_friend function will be called to get valid names to compare with 
            name1=get_friend(names)
            name2=get_friend(names)
        #Call the difference function to create a new set and assign it to a variable to be printed
            result=names[name1].difference(names[name2])
            print('These people are friends with {} but not friends with {}.\n{}'.format(name1, name2, result))
        if menu=='S':
    #The get_friend function will be called to get valid names to compare with
            name1=get_friend(names)
            name2=get_friend(names)
     #Call the symmetric_difference function to create a new set and assign it to a variable to be printed
            result=names[name1].symmetric_difference(names[name2])
            print('These people are friends with {} and {}, but not both.\n{}'.format(name1, name2, result))
    #If the user enters q then the loop will end
        if menu=='Q':
            ask=False

