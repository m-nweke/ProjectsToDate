//Michael Nweke
//CS201 
//Program1
//Student ID: 16278575
#include <iostream>
#include <iomanip>
using namespace std;
double get_area(double userLength, double userHeight) {
	double area;
	area = userLength * userHeight;
	return area;
}
double get_cans(double total_area) {
	int cans;
	double need;
	need = total_area / 400.0;
	cout << "As each can covers 400 feet" << endl;
	cout << "With area = " << total_area << " you will need to get " << need << endl;
	cans = ceil(need);
	cout << "So in total we need " << cans << " cans" << endl << endl;
	return cans;
}
int getIncost(int inCans) {
	int cost;
	cout << "Now lets calculate the cost to paint the interior of the house" << endl;
	cout << "The price of the can is $100" << endl;
	cost = 100 * inCans;
	cout << "The total cost for your " << inCans << " can is $" << cost << endl;
	return cost;
}

int getOutcost(int outCans) {
	int cost;
	cout << "Now lets calculate the cost to paint the exterior of the house" << endl;
	cout << "The price of the can is $150" << endl;
	cost = 150 * outCans;
	cout << "The total cost for your " << outCans << " can is $" << cost << endl;
	return cost;
}
int getBothcost(int inCans, int outCans) {
	int total=0;
	cout << "Now let's calculate the cost to paint both the interior and exterior of the house" << endl;
	cout << endl << "The price for interior cans are $100, you had " << inCans << " interior cans" << endl;
	cout << "The price for exterior cans are $150, you had " << outCans << " exterior cans" <<  endl;
	total += inCans * 100;
	total += outCans * 150;
	return total;
}
int main() {
	char choice;
	double area;
	double userLength;
	double userHeight;
	int walls;
	int i = 1;
	double Intotal_area=0;
	double Outtotal_area = 0;
	int inCans=0;
	int outCans=0;
	double total = 0;
	cout << "Welcome to the paint shop" << endl;
	cout << "We have a couple of options for you to choose from" << endl;
	cout << "1- Paint the interior of a house" << endl;
	cout << "2- Paint the exterior of a house" << endl;
	cout << "3- Paint both interior and exterior of a house" << endl;
	cout << "What option fits you more?" << endl;
	do {
		cin >> choice;
		switch (choice) {
		case '1':
			cout << "Now, how many walls do you want to paint?" << endl;
			cin >> walls;
			for (i = 1; i <= walls; i += 1) {
				cout << "What is the length and height for wall " << i << " :" << endl;
				cout << "Length = ";
				cin >> userLength;
				cout << endl << endl;
				cout << "Height = ";
				cin >> userHeight;
				area = get_area(userLength, userHeight);
				cout << "Area for wall " << i << " is " << area << endl << endl;
				Intotal_area += area;

			}
			inCans = get_cans(Intotal_area);
			getIncost(inCans);
			break;

		case '2':
			cout << "Now, how many walls do you want to paint?" << endl;
			cin >> walls;
			for (i = 1; i <= walls; i += 1) {
				cout << "What is the length and height for wall " << i << " :" << endl;
				cout << "Length = ";
				cin >> userLength;
				cout << endl << endl;
				cout << "Height = ";
				cin >> userHeight;
				area = get_area(userLength, userHeight);
				cout << "Area for wall " << i << " is " << area << endl << endl;
				Outtotal_area += area;

			}
			outCans = get_cans(Outtotal_area);
			getOutcost(outCans);
			break;

		case '3':
			cout << "Now, how many walls do you want to paint on the interior?" << endl;
			cin >> walls;
			for (i = 1; i <= walls; i += 1) {
				cout << "What is the length and height for wall " << i << " :" << endl;
				cout << "Length = ";
				cin >> userLength;
				cout << endl << endl;
				cout << "Height = ";
				cin >> userHeight;
				area = get_area(userLength, userHeight);
				cout << "Area for wall " << i << " is " << area << endl << endl;
				Intotal_area += area;

			}
			inCans = get_cans(Intotal_area);
			cout << "Now, how many walls do you want to paint on the exterior?" << endl;
			cin >> walls;
			for (i = 1; i <= walls; i += 1) {
				cout << "What is the length and height for wall " << i << " :" << endl;
				cout << "Length = ";
				cin >> userLength;
				cout << endl << endl;
				cout << "Height = ";
				cin >> userHeight;
				area = get_area(userLength, userHeight);
				cout << "Area for wall " << i << " is " << area << endl << endl;
				Outtotal_area += area;

			}
			outCans = get_cans(Outtotal_area);
			total += getBothcost(inCans, outCans);
			cout << "The total for the interior and exterior is $" << total << endl;
			break;

		default:
			cout << "Enter a valid input" << endl;
			break;
		}
	} while (choice != '1' && choice != '2' && choice != '3');
	system; "pause";
}